# Current Documentation Baseline — 2026-09-17

This file freezes the documentation authority and current architecture assumptions to use when creating or revising LoRaWAN infrastructure manuals. It is not a deployment runbook and it does not replace live verification.

## Authority order

When sources disagree, use this order:

1. Fresh verified live state, when access is available and the check is directly relevant.
2. [`../server/cloud-production/00-current-server-continuation-checkpoint.md`](../server/cloud-production/00-current-server-continuation-checkpoint.md) for the latest commissioned system boundary.
3. Current implementation, migrations, contracts, and deployment material under `../../evidence-services/` and the active gateway/firmware source trees.
4. Current component runbooks linked from the technology guides.
5. Dated build logs, archived plans, thesis extracts, and bring-up handoffs only as historical provenance.

A failed live probe is not evidence that a previously commissioned component changed state. During the 2026-09-17 documentation audit, a direct SSH probe from the documentation workspace was denied by public-key authentication, so this audit makes no new host-runtime claim from that failed attempt.

## Stable current architecture facts

- Regional plan is **plain AS923** and the MQTT region prefix is `as923`. Do not substitute AS923-3 unless an intentional end-to-end migration is later commissioned.
- Gateway-01 uses Raspberry Pi / ChirpStack Gateway OS, RAK5146, ChirpStack Concentratord, local persistent Mosquitto, and the software evidence journal/uploader. Gateway EUI is `0016c001f139a1cb`.
- SIM7600 `wwan0` is the health-gated production-primary WAN path. Wi-Fi is fallback; Ethernet is management-oriented and must not silently become the production data path.
- Cloud Mosquitto is preferred/backup service HA, not replicated MQTT-session active/active.
- ChirpStack runs as the commissioned two-node application/network-server tier; Valkey/Sentinel provides its HA cache/runtime support.
- PostgreSQL/Patroni/TimescaleDB is the three-member durable data layer, coordinated through etcd. HAProxy and PgBouncer provide stable routing/pooling.
- Node-RED is active/passive: ULC-03 is the active application writer and ULC-02 is fenced standby. Do not run both merely for availability.
- Grafana is read-only observability. Counted research truth comes from the research-recorder/sealed result artifacts, not dashboard screenshots alone.
- Gateway evidence ingest, MQTT collectors, verifier replicas, trusted decoder, PostgreSQL evidence metadata, and SeaweedFS raw evidence storage are commissioned. Real v2 gateway lineage has passed.
- OpenBao is the commissioned three-member KMS/Transit cluster used by the Fabric integration.
- HRC Task 37 is commissioned. Fresh 2026-09-18 read-only checks show ULC-01 `enabled=true` / `status=ready` with worker `fabric-adapter-ulc-01`, while ULC-02 is healthy `enabled=false` / `status=standby`. ULC-02 remains fenced because its live image reference differs from ULC-01 and current image parity/generation-fencing takeover acceptance has not yet been re-proven.

## Current Fabric contract

```text
Gateway endpoint: 10.104.0.7:7051
TLS server name:  peer1.hrc.local
MSP:              HrcMSP
Channel:          hrc-channel
Chaincode:        hrc-evidence
Source namespace: lorawan-gateway-evidence

CreateSourceBoundAnchor(SourceRecordID, sourceType, producer, producedAt, schemaVersion)
  transient hrc.exact_payload = immutable finalized_payload bytes
QuerySourceBoundAnchor(SourceRecordID)
VerifySourceBoundDigest(SourceRecordID, sha256(finalized_payload))
```

The retired `CreateAnchor`, `QueryAnchor`, `QueryAnchorByRecordID`, and `VerifyDigest` APIs must not be restored. Exact `finalized_payload` bytes must never be reconstructed from JSONB, `raw_data`, maps, structs, or projections.

For a new Fabric claim, `finalized_payload IS NOT NULL` is mandatory. A `telemetry-attestation-v2` row additionally requires exactly matching verifier-owned `status='verified'`. Therefore a row can remain `pending` with `attempts=0` while the Fabric writer itself is healthy.

Current post-submit lifecycle is `reconciling` for uncertain recoverable state and `needs_attention` for permanent/conflicting evidence. `submitted_unknown` remains only as migration compatibility and is not emitted by the current worker. Prepared transaction bytes and the signed commit-status request are persisted so recovery can use the same transaction rather than blindly resubmitting.

## Open gates that must stay visible

- ULC-02 Fabric takeover/ownership/fencing acceptance. Fresh 2026-09-18 state is intentionally blocked before takeover because ULC-01 reports `gateway-fabric-adapter:fairness-20260915` while ULC-02 reports `9e08e25fe5dd`; load/verify one accepted current build on both nodes while ULC-02 remains disabled, verify worker identity and migration 003, then run the controlled failover gate.
- DigitalOcean Reserved IPv4 reassignment authority and controlled failover acceptance.
- Upstream research outbox finalization/eligibility for any future rows that lack immutable `finalized_payload` or required verifier state. The fresh 2026-09-18 monitor snapshot showed `2094/2094` Fabric outbox rows confirmed and `2094/2094` evidence verifications verified, so the earlier pending backlog is historical rather than a current blocker.
- Explicitly deferred destructive backup/restore and failure-injection acceptance tests.
- Experiment-specific research GO/NO-GO gates under `test/`; a commissioned infrastructure layer does not automatically make every experiment ready.

## Superseded statements — never copy as current truth

Do not reintroduce these into active manuals:

- `AS923-3` as the commissioned regional plan.
- `GATEWAY_EVIDENCE_RUNTIME=SERVER_PASS_GATEWAY_PENDING`.
- `GATEWAY_EVIDENCE_V2_NORMAL_PATH=NOT_YET_CLAIMED`.
- “Fabric handoff pending” or “adapter image missing” for the current HRC deployment.
- Instructions to run ULC-01 and ULC-02 simultaneously as enabled Fabric writers.
- `submitted_unknown` as the normal current uncertain-submit state.
- The retired HRC Fabric transaction names listed above.
- Historical commissioning status statements from `00-build-execution-log.md` or `docs/archive/**` presented as present-tense operator instructions.

## Standard structure for final technology documentation

For each technology, document: purpose and ownership; current placement; interfaces and ports; dependencies; current configuration/identity; normal operations; recovery; verification/acceptance; troubleshooting by failing layer; security boundaries; and authoritative references. Keep chronological debugging detail in historical logs rather than duplicating it into current manuals.
