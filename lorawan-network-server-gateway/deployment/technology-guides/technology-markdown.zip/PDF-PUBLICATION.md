# Technology Documentation — Markdown and PDF Publication

## Canonical source

The **21 numbered Markdown guides** in this directory are the editable technology/operator documentation. The existing 20 guides remain authoritative in their respective domains; [21](21-end-to-end-integration-and-data-lineage.md) adds cross-technology interfaces and failure isolation. [00-README.md](00-README.md) provides navigation, and [CURRENT-DOCUMENTATION-BASELINE.md](CURRENT-DOCUMENTATION-BASELINE.md) records the dated authority boundary.

Dedicated PDFs are **derived publications, not a second source of truth**. Revise the appropriate Markdown guide and verify its facts *before* exporting the corresponding PDF. Never hand-edit only the PDF.

## Publication set

- One dedicated PDF for each numbered Markdown guide, `01` through `21`. Each dedicated PDF includes its operator guide **and copies of the linked project implementation/recovery runbooks as clearly labeled supporting appendices**, so a reader does not have to open the repository merely to find the detailed procedure. Appendices retain their original Markdown authority and may contain dated historical details: compare with the current baseline and live system before applying changes. Do not merge all 21 into a single unreadable operations volume.
- One short navigation PDF derived from `00-README.md`, if useful for distribution.
- No release PDF from `CURRENT-DOCUMENTATION-BASELINE.md` alone: link or bundle that dated note instead.
- Keep the dissertation research testing manual separate from the platform technology/operator manuals; its authority is `../../test/`, not a generated snapshot of these guides.

Output naming convention: `pdf/<source-basename>.pdf`, with a manifest that includes the source Markdown and PDF SHA-256 hashes and generation timestamp. Source-relative links in PDFs must be rendered as readable text or actual hyperlinks; test after conversion.

## Checklist before each publication

1. Read [current baseline](CURRENT-DOCUMENTATION-BASELINE.md) and compare any mutable status statement with a **dated** operational checkpoint or fresh authorized read-only check.
2. Ensure the guide identifies purpose, ownership/placement, dependencies, actual interface, security boundary, safe health check, expected result, troubleshooting order, backup/rollback, recovery, and references. The guide is not a vendor manual.
3. Validate the referred configuration, source files, scripts, paths, and local Markdown links. Do not silently reuse historical commissioning or test output as present-tense evidence.
4. Keep **plain AS923** and `as923` in the current gateway/network/device instructions unless an intentionally verified migration changes the plan.
5. Preserve the correct HA roles: ULC-03 active / ULC-02 fenced Node-RED; ULC-01 enabled / ULC-02 disabled Fabric writer pending the separate HA gate; broker preferred/backup rather than active/active MQTT sessions.
6. Preserve the exact v2 evidence and HRC source-bound contracts in [adapter guide](15-hyperledger-fabric-adapter.md); do not equate `pending attempts=0` with writer failure.
7. Prevent publication of passwords, OTAA root keys, tokens, private key bodies, OpenBao recovery material, unrestricted DSNs, protected host environment values, or secrets accidentally captured in command output.
8. Generate from the **current local Markdown**, render PDF pages and inspect cover, representative table, code block and final page for overflow, clipped text or unreadable glyphs.
9. Validate PDF text extractability/search and page count; record source/PDF hashes. Label unreverified live-state claims as historical checkpoints.
10. Avoid disruptive live tests merely to publish documentation. Hardware or infrastructure retests belong to the dedicated research or acceptance workflow.

## Source and publication inventory

| Publication | Markdown authority |
|---|---|
| Gateway OS/OpenWrt | [01](01-gateway-os-openwrt.md) |
| RAK5146/Concentratord/AS923 | [02](02-rak5146-concentratord-as923.md) |
| SIM7600/LTE | [03](03-sim7600-lte-backhaul.md) |
| Mosquitto | [04](04-mosquitto-mqtt.md) |
| ChirpStack | [05](05-chirpstack.md) |
| etcd | [06](06-etcd.md) |
| PostgreSQL/Patroni/TimescaleDB | [07](07-postgresql-patroni-timescaledb.md) |
| HAProxy/PgBouncer | [08](08-haproxy-pgbouncer.md) |
| Valkey/Sentinel | [09](09-valkey-sentinel.md) |
| Node-RED | [10](10-node-red.md) |
| Grafana | [11](11-grafana.md) |
| OpenBao | [12](12-openbao.md) |
| SeaweedFS | [13](13-seaweedfs.md) |
| Gateway evidence services | [14](14-gateway-evidence-services.md) |
| HRC Fabric adapter | [15](15-hyperledger-fabric-adapter.md) |
| Host/container/cloud platform | [16](16-runtime-and-cloud-platform.md) |
| PKI/TLS/identity | [17](17-pki-tls-and-service-identity.md) |
| WisBlock sensor firmware | [18](18-rak4631-wisblock-sensor-firmware.md) |
| Research recorder/automation | [19](19-research-recorder-and-test-automation.md) |
| RUI3 security node | [20](20-rui3-security-node.md) |
| Cross-technology interfaces/lineage | [21](21-end-to-end-integration-and-data-lineage.md) |

## Known publication limits

The current 20 established manuals and this new integration guide describe a **commissioned architecture plus dated checkpoints**, not a claim that every interface is healthy at PDF generation time. Consult the actual current operational state before performing high-impact procedures. Experiment-specific readiness still comes from `../../test/` GO/NO-GO results and sealed artifacts.

For fresh rebuilds, use the linked full deployment/recovery runbooks; the concise technology manuals explain the components and safe diagnosis but are not substitutes for every low-level installation file.
